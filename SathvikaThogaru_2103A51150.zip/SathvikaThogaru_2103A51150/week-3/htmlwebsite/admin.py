from django.contrib import admin

from htmlwebsite.models import CandidateDetails, Contact, Party, VoterDetails



# Register your models here.
admin.site.register(Contact)
admin.site.register(VoterDetails)
admin.site.register(CandidateDetails)
admin.site.register(Party)